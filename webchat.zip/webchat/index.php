<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>web Chat</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div id="main">
		<div id="info">
			<h2>Login Here</h2>
			<form action="Login.php" method="post">
				<label><b></b>UserName</label>
				<input type="text" name="uname" placeholder="UserName"><br><br>

				<label><b></b>Password</label>
				<input type="text" name="pass" placeholder="Password">
				<button type="submit"><b>Login</button>
			</form>

			<form action="signup.php" method="post">
				<h2>Don't have an Account? sign up here</h2>

				<label><b></b>UserName</label>
				<input type="text" name="uname" placeholder="UserName"><br><br>

				<label><b></b>Email</label>
				<input type="text" name="Email" placeholder="Email"><br><br>

				<label><b></b>Password</label>
				<input type="text" name="Password" placeholder="Password">

				<button type="submit"><b>Sign Up</button>
			</form>
		</div>
	</div>
</body>
</html>