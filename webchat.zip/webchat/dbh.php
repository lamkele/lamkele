<?php

$conn = mysqli_connect("localhost", "root", "", "mydatabase");
if(!$conn){
	die("connection failed".mysql_connect_error());
}




?>