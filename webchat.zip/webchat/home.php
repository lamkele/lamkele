<?php
session_start();
include 'dbh.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div id="main-home">

		<h3><?php echo$_SESSION['name']?>-online</h3>
			<div class="output">
				<?php

				$sql= "SELECT * FROM post";

				$result = $conn->query($sql);
				//show words on the outpu area

				if($result->num_rows > 0){
					while ($row= $result->fetch_assoc()) {
						
						echo "".$row['name']." "."::". $row["msg"]." --".$row["date"]."<br>";
						echo "<br>";
					}
				}else{
						echo "0 results";

					}
					$conn->close();
				
				?>

			</div>

			<form action="send.php" method="post">
				<textarea name="msg" placeholder="type to send message..." class="forn-control"></textarea><br><br>
				<input type="submit" value="send">
			</form>
			<br>

			<form action="logout.php">
				<input type="submitt" value="Logout">

			</form>
	</div>


</body>
</html>